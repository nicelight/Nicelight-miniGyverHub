#include "WiFiConnector.h"

WiFiConnectorClass WiFiConnector;