#include "fs.h"

namespace sets {

FSClass FS;

}  // namespace sets
