#include "SettingsBase_class.h"

namespace sets {

SettingsBase* thisSettings = nullptr;

}  // namespace sets